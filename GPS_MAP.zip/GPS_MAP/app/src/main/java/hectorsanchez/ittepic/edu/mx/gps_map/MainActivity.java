package hectorsanchez.ittepic.edu.mx.gps_map;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Marker marcador;
    double lat = 0.0;
    double lng = 0.0;
    Conexion bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bd = new Conexion(this, "Diccionario", null, 1);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        leer();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        miUbicaion();mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {
                mMap.addMarker(new MarkerOptions()
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.ubi))
                        .anchor(0.0f, 1.0f)
                        .title("Marcadores")
                        .position(latLng));
                enviar(latLng.latitude,latLng.longitude);

            }
        });

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                Toast.makeText(getApplicationContext(),"Has pulsado una marca", Toast.LENGTH_LONG).show();
                return false;
            }
        });
    }

    private void agregarMarcador(double lat, double lng) {
        LatLng coordenadas = new LatLng(lat, lng);
        CameraUpdate miUbicacion = CameraUpdateFactory.newLatLngZoom(coordenadas, 16);
        if (marcador != null) marcador.remove();
        marcador = mMap.addMarker(new MarkerOptions()
                .position(coordenadas)
                .title("Mi posicion")
                .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_launcher))

        );
    }
    private void agregarMarcador2(double lat, double lng) {

        LatLng coordenadas = new LatLng(lat, lng);

        mMap.addMarker(new MarkerOptions()
                .position(coordenadas)
                .title("Mi posicion")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.ubi))

        );

    }
    public void enviar(double lat, double lan) {


        try {

            SQLiteDatabase base = bd.getWritableDatabase();
            String SQL = "INSERT INTO Tabla VALUES(NULL," + lat + "," + lan + ")";
            base.execSQL(SQL);
            base.close();
            Toast.makeText(MainActivity.this, "Se inserto correctamente", Toast.LENGTH_SHORT).show();
            //startActivity(new Intent(MainActivity.this, Activity_mostrar.class));
            // finish();


        } catch (SQLException e) {

            Toast.makeText(MainActivity.this, e.getMessage() + "Existen campos vacios", Toast.LENGTH_SHORT).show();

        }

    }
    public void leer() {

        try {
            SQLiteDatabase base = bd.getReadableDatabase();

            String sql = "SELECT * FROM Tabla";


            Cursor cursor = base.rawQuery(sql, null);



            if (cursor.moveToFirst()) {
                do {
                    agregarMarcador2((Double.parseDouble(cursor.getString(1))),Double.parseDouble(cursor.getString(2)));


                } while (cursor.moveToNext());

            } else {
                Toast.makeText(MainActivity.this, "no existe", Toast.LENGTH_LONG).show();


            }
            cursor.close();
            base.close();
        } catch (SQLiteException sqle) {
            Toast.makeText(MainActivity.this, "no existe", Toast.LENGTH_SHORT).show();
        }

    }

    private void actulizarUbicion(Location location) {

        if (location != null) {
            lat = location.getLatitude();
            lng = location.getLongitude();
            agregarMarcador(lat, lng);
        }


    }

    LocationListener locListener = new LocationListener() {

        @Override
        public void onLocationChanged(Location location) {
            actulizarUbicion(location); leer();
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    };


    private void miUbicaion() {

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {


            return;
        }
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        actulizarUbicion(location);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1500,0, locListener);
    }
}
