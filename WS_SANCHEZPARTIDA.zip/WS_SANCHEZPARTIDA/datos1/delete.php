<?php include('functions.php');
$idalumno=$_GET['idalumno'];


ejecutarSQLCommand("DELETE FROM  `Alumnos` WHERE idalumno='$idalumno';");

 ?>