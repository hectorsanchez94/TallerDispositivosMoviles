<?php
/**
 * Insertar un nuevo alumno en la base de datos
 */
/*require 'Alumnos.php';

$hostname_localhost ="localhost";  //nuestro servidor
$database_localhost ="Datos";//Nombre de nuestra base de datos
$username_localhost ="root";//Nombre de usuario de nuestra base de datos (yo utilizo el valor por defecto)
$password_localhost ="";//Contraseña de nuestra base de datos (yo utilizo por defecto)
$localhost = mysql_connect($hostname_localhost,$username_localhost,$password_localhost)//Conexión a nuestro servidor mysql
or
trigger_error(mysql_error(),E_USER_ERROR); //mensaaje de error si no se puede conectar
mysql_select_db($database_localhost, $localhost);//seleccion de la base de datos con la qu se desea trabajar

//variables que almacenan los valores que enviamos por nuestra app, (observar que se llaman igual en nuestra app y aqui)
$nombre=$_POST['nombre'];
$direccion=$_POST['direccion'];

$registros=array();

$query_search = "INSERT INTO Alumnos(nombre,direccion) VALUES ('$nombre','$direccion')";//Sentencia sql a realizar
$query_exec = mysql_query($query_search);//Ejecuta la sentencia sql.

$registros = ["resultado"] = true;
$registros = ["mensaje"] = "usuario creado";

echo json_encode($registros);*/

require 'Alumnos.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Decodificando formato Json
    $body = json_decode(file_get_contents("php://input"), true);
    // Insertar Alumno
    $retorno = Alumnos::insert(
        $body['nombre'],
        $body['direccion']);
    if ($retorno) {
        $json_string = json_encode(array("estado" => 1,"mensaje" => "Creacion correcta"));
		echo $json_string;
    } else {
        $json_string = json_encode(array("estado" => 2,"mensaje" => "No se creo el registro"));
		echo $json_string;
    }
}
?>