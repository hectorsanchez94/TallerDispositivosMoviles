<?php
include('functions.php');
$idalumno=$_GET["idalumno"];


if($resultset=getSQLResultSet("SELECT * FROM `Alumnos` WHERE idalumno='$idalumno'")){
	while ($row = $resultset->fetch_array(MYSQLI_NUM)){
		echo json_encode($row);
	}
}

?>


