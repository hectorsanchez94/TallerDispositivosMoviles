<?php include('functions.php');
$idalumno=$_GET['idalumno'];
$nombre=$_GET['nombre'];
$direccion=$_GET['direccion'];


ejecutarSQLCommand("UPDATE  `Alumnos` SET nombre='$nombre', direccion='$direccion' WHERE idalumno='$idalumno';");

 ?>