<?php include('functions.php');
$nombre=$_GET['nombre'];
$direccion=$_GET['direccion'];


ejecutarSQLCommand("INSERT INTO  `Alumnos` (nombre, direccion)
VALUES (
'$nombre' ,
'$direccion')

 ON DUPLICATE KEY UPDATE `nombre`= '$nombre',
`direccion`='$direccion';");

 ?>