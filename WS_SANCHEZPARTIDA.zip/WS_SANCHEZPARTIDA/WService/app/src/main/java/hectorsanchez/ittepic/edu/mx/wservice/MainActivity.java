package hectorsanchez.ittepic.edu.mx.wservice;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    Button btnconsultar, btnGuardar, btnConsultaTodo, btnActualizar, btnBorrar;
    EditText etId, etNombres, etTelefono;
    TextView resultad;
    String JSON_STRING;
    String json_string;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnconsultar = (Button) findViewById(R.id.btnConsultar);
        btnGuardar = (Button) findViewById(R.id.btnGuardar);
        btnConsultaTodo=(Button)findViewById(R.id.consulta_todo);
        btnActualizar=(Button) findViewById(R.id.actualizar);
        btnBorrar=(Button)findViewById(R.id.borrar);
        etId = (EditText) findViewById(R.id.etId);
        etNombres = (EditText) findViewById(R.id.etNombres);
        etTelefono = (EditText) findViewById(R.id.etTelefono);
        resultad = (TextView) findViewById(R.id.tvTitulo);

        btnConsultaTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new  WServices().execute("http://10.0.3.2/datos1/obtener_alumnos.php", "1");
            }
        });
        btnconsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new ConsultarDatos().execute("http://10.0.3.2/datos1/consulta.php?idalumno=" + etId.getText().toString());
            }
        });

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CargarDatos().execute("http://10.0.3.2/datos1/registro.php?nombre=" + etNombres.getText().toString() + "&direccion=" + etTelefono.getText().toString());
                etId.setText("");
                etNombres.setText("");
                etTelefono.setText("");
            }
        });

        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new UpdateDatos().execute("http://10.0.3.2/datos1/update.php?idalumno="+etId.getText().toString()+"&nombre=" + etNombres.getText().toString() + "&direccion=" + etTelefono.getText().toString());
                etId.setText("");
                etNombres.setText("");
                etTelefono.setText("");
            }
        });

        btnBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DeleteDatos().execute("http://10.0.3.2/datos1/delete.php?idalumno="+etId.getText().toString());
                etId.setText("");
                etNombres.setText("");
                etTelefono.setText("");
            }
        });
    }

    private class CargarDatos extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            // params comes from the execute() call: params[0] is the url.
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                return "Unable to retrieve web page. URL may be invalid.";
            }
        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

            Toast.makeText(getApplicationContext(), "Se almacenaron los datos correctamente", Toast.LENGTH_LONG).show();

        }
    }

    private class UpdateDatos extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            // params comes from the execute() call: params[0] is the url.
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                return "Unable to retrieve web page. URL may be invalid.";
            }
        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

            Toast.makeText(getApplicationContext(), "Se actualizaron los datos correctamente", Toast.LENGTH_LONG).show();

        }
    }

    private class DeleteDatos extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            // params comes from the execute() call: params[0] is the url.
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                return "Unable to retrieve web page. URL may be invalid.";
            }
        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

            Toast.makeText(getApplicationContext(), "Registro borrado con exito", Toast.LENGTH_LONG).show();

        }
    }

    private class ConsultarDatos extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            // params comes from the execute() call: params[0] is the url.
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                return "Unable to retrieve web page. URL may be invalid.";
            }
        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

            JSONArray ja = null;
            try {
                ja = new JSONArray(result);
                etNombres.setText(ja.getString(1));
                etTelefono.setText(ja.getString(2));
                resultad.setText("");

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private String downloadUrl(String myurl) throws IOException {
        Log.i("URL", "" + myurl);
        myurl = myurl.replace(" ", "%20");
        InputStream is = null;
        // Only display the first 500 characters of the retrieved
        // web page content.
        int len = 500;

        try {
            URL url = new URL(myurl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000 /* milliseconds */);
            conn.setConnectTimeout(15000 /* milliseconds */);
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            // Starts the query
            conn.connect();
            int response = conn.getResponseCode();
            Log.d("respuesta", "The response is: " + response);
            is = conn.getInputStream();

            // Convert the InputStream into a string
            String contentAsString = readIt(is, len);
            return contentAsString;

            // Makes sure that the InputStream is closed after the app is
            // finished using it.
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }

    public String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        char[] buffer = new char[len];
        reader.read(buffer);
        return new String(buffer);
    }

    public class WServices extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            URL url;
            String cadena = "";
            if (params[1] == "1") {

                try {
                    url = new URL("http://10.0.3.2/datos1/obtener_alumnos.php");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection(); // Abrir conexion
                    int respuesta = connection.getResponseCode();
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();
                    if (respuesta == HttpURLConnection.HTTP_OK) {
                        //Toast.makeText(getApplicationContext(), "HTTP_OK "+cadena, Toast.LENGTH_SHORT).show();
                        while ((json_string = bufferedReader.readLine()) != null) {

                            stringBuilder.append(json_string + "\n");

                        }
                        bufferedReader.close();
                        inputStream.close();
                        connection.disconnect();
                        cadena = stringBuilder.toString().trim();
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } // Caso GET_TODO

            return cadena;

        }

        @Override
        protected void onPreExecute() {


            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String result) {
            resultad.setText(result);
            JSON_STRING = result;
        }
    }
}
